from .module1 import SomeClass
from .module2 import some_function
__version__ = '1.0'
__author__ = 'Omar Dev'

